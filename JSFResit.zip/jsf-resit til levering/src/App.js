import "./sass/style.scss";
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./components/home/Home";
import Grass from "./components/grass/Grass";
import Contact from "./components/contact/Contact";
import Navigation from "./components/layout/Navigation";
import Details from "./components/details/Details";

function App() {
  return (
    <Router>
      <Navigation />

      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/grass" element={<Grass />}></Route>
        <Route path="/contact" element={<Contact />}></Route>
        <Route path="/details/:id" element={<Details />}></Route>
      </Routes>
    </Router>
  );
}

export default App;
