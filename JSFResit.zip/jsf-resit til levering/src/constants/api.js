export const API = "https://api.pokemontcg.io/v1/cards?setCode=base1";
