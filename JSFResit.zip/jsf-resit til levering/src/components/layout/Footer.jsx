import logo from "../../img/logo.png";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <>
      <div className="footer">
        <Link to="/">
          <img src={logo} className="logo" alt="logo" />
          Pokémon
        </Link>
      </div>
    </>
  );
}
