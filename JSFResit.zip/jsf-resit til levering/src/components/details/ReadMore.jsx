import React, { useState } from "react";

function ReadMore() {
  const [readMore, setReadMore] = useState(false);

  const extraContent = (
    <div className="extra_content">
      <p>..</p>
    </div>
  );

  const linkName = readMore ? "Read Less " : "Read more ";

  return (
    <div>
      <a
        href="true"
        className="read_more_link"
        onClick={() => {
          setReadMore(!readMore);
        }}
      >
        {linkName}
      </a>
      {readMore && extraContent}
    </div>
  );
}

export default ReadMore;
