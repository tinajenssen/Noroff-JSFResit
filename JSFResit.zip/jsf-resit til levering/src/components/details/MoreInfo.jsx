import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

function MoreInfo() {
  const [pokemon, setPokemon] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const { id } = useParams();

  const url = "https://api.pokemontcg.io/v1/cards/" + id;

  useEffect(
    function () {
      async function fetchData() {
        try {
          const response = await fetch(url);

          if (response.ok) {
            const json = await response.json();
            console.log(json);
            setPokemon(json.card);
          } else {
            setError("An error occured");
          }
        } catch (error) {
          setError(error.toString());
        } finally {
          setLoading(false);
        }
      }
      fetchData();
    },
    [url]
  );

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>An error occured: {error}</div>;
  }

  return (
    <div>
      <p>{pokemon.hp} HP</p>
      <p>{pokemon.types} </p>
      <p>{pokemon.rarity} </p>
    </div>
  );
}

export default MoreInfo;
