import PokemonDetail from "../pokemon/PokemonDetails";
import Footer from "../layout/Footer";
import Container from "react-bootstrap/Container";

export default function Details() {
  return (
    <>
      <div className="wrapper">
        <Container>
          <PokemonDetail />
        </Container>
      </div>
      <Footer />
    </>
  );
}
