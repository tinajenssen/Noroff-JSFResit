import Heading from "../layout/Heading";
import GrassPokemons from "./GrassPokemons";
import Footer from "../layout/Footer";
import Container from "react-bootstrap/Container";

export default function Grass() {
  return (
    <>
      <div className="wrapper">
        <Container>
          <Heading title="Grass" />
          <GrassPokemons />
        </Container>
      </div>
      <Footer />
    </>
  );
}
