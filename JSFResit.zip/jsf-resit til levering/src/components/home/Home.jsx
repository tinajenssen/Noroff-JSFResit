import Heading from "../layout/Heading";
import PokemonList from "../pokemon/PokemonList";
import Footer from "../layout/Footer";
import Container from "react-bootstrap/Container";

export default function Home() {
  return (
    <>
      <div className="wrapper">
        <Container>
          <Heading title="Home" />
          <PokemonList />
        </Container>
      </div>

      <Footer />
    </>
  );
}
