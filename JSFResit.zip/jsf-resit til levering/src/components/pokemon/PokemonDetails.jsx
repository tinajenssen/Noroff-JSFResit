import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import ReadMore from "../details/ReadMore";

function PokemonDetail() {
  const [pokemon, setPokemon] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  let navigate = useNavigate();

  const { id } = useParams();

  if (!id) {
    navigate.push("/");
  }

  const url = "https://api.pokemontcg.io/v1/cards/" + id;

  useEffect(
    function () {
      async function fetchData() {
        try {
          const response = await fetch(url);

          if (response.ok) {
            const json = await response.json();
            console.log(json);
            setPokemon(json.card);
          } else {
            setError("An error occured");
          }
        } catch (error) {
          setError(error.toString());
        } finally {
          setLoading(false);
        }
      }
      fetchData();
    },
    [url]
  );

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>An error occured: {error}</div>;
  }

  return (
    <div className="pokemon_details">
      <div className="card_img">
        <img src={pokemon.imageUrl} alt="" />
      </div>
      <div className="card_info">
        <h2>{pokemon.name}</h2>

        <ReadMore />
      </div>
    </div>
  );
}

export default PokemonDetail;
