import PropTypes from "prop-types";
import { Link } from "react-router-dom";

import Col from "react-bootstrap/Col";

function PokemonCard({ id, name, imageUrl, types, number }) {
  return (
    <>
      <Col xs={12} sm={6} md={4} lg={3} className="card">
        <div>
          <img src={imageUrl} alt="" />
        </div>

        <Link to={`details/${id}`} className="btn">
          {name}
        </Link>
      </Col>
    </>
  );
}

PokemonCard.propTypes = {
  id: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
};

export default PokemonCard;
