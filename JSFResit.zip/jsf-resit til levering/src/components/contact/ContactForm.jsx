import React from "react";
import { useForm } from "react-hook-form";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";

const schema = yup.object().shape({
  name: yup.string().required("Please enter your name"),
  phone: yup.number().required("Please enter your phone number"),
  message: yup
    .string()
    .required("Please write your message")
    .min(10, "The message must be at least 10 characters"),
});

function ContactForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  function onSubmit(data) {
    console.log(data);
  }
  console.log(errors);

  return (
    <fieldset>
      <form className="contact-form" onSubmit={handleSubmit(onSubmit)}>
        {errors.name && <span>{errors.name.message}</span>}
        <input placeholder="Name" {...register("name")} />
        {errors.phone && <span>{errors.phone.message}</span>}
        <input placeholder="Phone number" {...register("phone")} />
        <select {...register("Select", { required: true })}>
          <option value="Enquiry">Enquiry</option>
          <option value="Complaint">Complaint</option>
          <option value="Compliment">Compliment</option>
          <option value="GeneralMessahe">General message</option>
        </select>
        {errors.message && <span>{errors.message.message}</span>}
        <textarea placeholder="Your message" {...register("message")} />

        <button className="btn">Send</button>
      </form>
    </fieldset>
  );
}

export default ContactForm;
