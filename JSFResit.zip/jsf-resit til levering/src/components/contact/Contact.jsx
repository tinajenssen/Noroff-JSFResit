import Heading from "../layout/Heading";
import Footer from "../layout/Footer";
import Container from "react-bootstrap/Container";
import ContactForm from "./ContactForm";

export default function Contact() {
  return (
    <>
      <div className="wrapper">
        <Container>
          <Heading title="Contact" />
          <ContactForm />
        </Container>
      </div>

      <Footer />
    </>
  );
}
